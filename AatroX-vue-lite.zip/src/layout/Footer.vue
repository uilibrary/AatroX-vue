<script>
export default {}
</script>

<template>
    <footer class="mt-10">
        <div class="container-fluid mx-auto">
            <BaseCard class="">
                <div class="flex justify-between items-center">
                    <a
                        target="_blank"
                        href="https://aatrox-vue.netlify.app/"
                        style="position: fixed;
                         bottom: 14px; right: 80px"
                        class="
                            py-3
                            px-5
                            inline-block
                            bg-green-500
                            text-white
                            btn
                            rounded
                            font-normal
                            leading-4
                            ripple
                        "
                        >Get Aatrox Pro</a
                    >
                    <div>
                        <p>All rights reserved © UI Lib 2021</p>
                    </div>
                </div>
            </BaseCard>
        </div>
    </footer>
</template>
